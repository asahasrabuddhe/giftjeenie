<?php

/**
 * These are the database login details
 */
define("HOST", "localhost");     	// The host you want to connect to.
define("USER", "root");    			// The database username. 
define("PASSWORD", "KaaliMirch");	// The database password. 
define("DATABASE", "giftjeenie");	// The database name.